
# Name        :   Vismaya Menon
# UTA ID      :   1001740500
#References   : https://stackoverflow.com/questions/45584453/how-to-create-a-simple-http-webserver-in-python
#               https://docs.python.org/3/library/http.server.html
#               https://wiki.python.org/moin/BaseHttpServer



from http.server import HTTPServer, BaseHTTPRequestHandler
import sys

#default  port
s_port = 8080 

#if there is an optional port number; parameter is passed, where server listens to clients
if 2 == len(sys.argv):
    s_port = int(sys.argv[1])

print('Server is listening to:', s_port)

# initialising HTTPServer 
class Srvr(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = '/default.html' 
        print('File to access is ', self.path[1:])
        try:
            file_to_open = open(self.path[1:]).read()
            self.send_response(200)
        except:
            file_to_open = "Page Not Found"
            self.send_response(404)
        self.end_headers()
        self.wfile.write(bytes(file_to_open,'utf-8'))

# intialising multi thread HTTP server with the port
http_mt = HTTPServer(('localhost',s_port),Srvr)
# keeping the server open always.
http_mt.serve_forever()