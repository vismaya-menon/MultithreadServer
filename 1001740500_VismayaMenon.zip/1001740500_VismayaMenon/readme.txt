
UTA ID	: 1001740500
Name	: Vismaya Menon


Client-Server program


1. Through command prompt, go to the folder 1001740500_VismayaMenon
2. Use the command dir to see the contents of the folder.
	   The folder has 5 files.
	   -file/in/path directory with an HTML page inpath_file.html
	   -cctrp.py (client connection response page)
	   -server.py
	   -default.html
	   -index.html
3. Run: py server.py
	A new tab will open. It will read "Server is listening to: 8080"
4. Open tabs in Chrome.
		- Type http://localhost:8080/ :- This will open Default page
		- Type http://localhost:8080/default.html :- This will also open default page
		- Type http://localhost:8080/index.html  :- This will open Index page
		- Type http://localhost:8080/file/in/path/inpath_file.html :- This will open InPath page
		- Tyoe http://localhost:8080/anypage.html :- This will show an error "Page Not Found"
		- Type http://localhost:8080/trial.html :- This will show an error "Page Not Found"
5. In command prompt, then run :-
	   - py cctrp.py localhost :- Displays default page contents in prompt.
	   - py cctrp.py localhost 8080 :- Also displays default page contents in prompt.
	   - py cctrp.py localhost 8080 default.html :- Also displays default page contents in prompt.
	   - py cctrp.py 127.0.0.1 :- Again displays default page contents in prompt.
	   - py cctrp.py localhost 8080 index.html :- Displays Index page contents in prompt.
	   - py cctrp.py localhost 8080 file/in/path/inpath_file.html :- Displays InPath page contents in prompt.
	   - py cctrp.py localhost 8080 anypage.html :- Displays error code and message "Page Not Found" in prompt.
	   - py cctrp.py localhost 8080 trial.html :- Displays error code and message "Page Not Found" in prompt.
   
   
   
   
   

References used for the project:
https://docs.python.org/3/library/http.client.html
https://stackoverflow.com/questions/24671566/http-client-request-method-in-python-3
https://www.programcreek.com/python/example/85794/http.client.HTTPSConnection
https://www.twilio.com/blog/2016/12/http-requests-in-python-3.html
https://stackoverflow.com/questions/45584453/how-to-create-a-simple-http-webserver-in-python
https://docs.python.org/3/library/http.server.html
https://wiki.python.org/moin/BaseHttpServer
https://www.youtube.com/watch?v=Lbfe3-v7yE0&t=307s
https://www.youtube.com/watch?v=pP8F7tRIPyo
