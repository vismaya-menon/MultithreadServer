
# Name        :   Vismaya Menon
# UTA ID      :   1001740500
#References   :  https://docs.python.org/3/library/http.client.html
#                https://stackoverflow.com/questions/24671566/http-client-request-method-in-python-3
#                https://www.programcreek.com/python/example/85794/http.client.HTTPSConnection
#                https://www.twilio.com/blog/2016/12/http-requests-in-python-3.html



import http.client
import sys

# Default values
s_name = "localhost"
s_port = 8080
f_name = "default.html"

# Defining usage of the program
def usage():
    print("\nUsage  : py cctrp.py  <server_IPaddress/name> [<port_number>] [<requested_f_name>]"
          "\n         <server_IPaddress/name> : Mandatory, <port_number> : Optional, <requested_f_name> : Optional"
          "\nexample  : py cctrp.py localhost"
          "\n           py cctrp.py 127.0.01 8080 default.html"
          "\n           py cctrp.py 127.0.01 default.html")



if 1 == len(sys.argv):
    print("\nInadequate number of arguments")
    usage()
    exit()

s_name = str(sys.argv[1])

if 4 == len(sys.argv):
    s_port = int(sys.argv[2])
    f_name = str(sys.argv[3])
if 3 == len(sys.argv):
    try:
        s_port = int(sys.argv[2])
    except ValueError:
        f_name = str(sys.argv[2])


print("\nServer name/IP: ", s_name, ", Server port: ", s_port, ", Name of the file to download: ", f_name)

f_name = '/' + f_name #The server loses first character while fetching the file with the name

# HTTP connection
try:
    connection = http.client.HTTPConnection(s_name, s_port, timeout=25)
    connection.request("GET",f_name)
    response = connection.getresponse()
    print("\nStatus code: {}, Reason phrase: {}".format(response.status, response.reason))
    content = response.read()
    if 'Page Not Found' != str(content.decode()):
        print("\nRequested content is below\n")
    else:
        print("Content")
    print(content.decode())
except:
    print("\nConnection could not be made due to unexpected error. Please check Server Name/IP or Port Number")
    usage()

#close the connection.
connection.close()